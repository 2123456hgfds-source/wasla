import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function SettingsPage() {
  return (
    <div>
      <PageHeader title="الإعدادات" description="تحكّم بحسابك وتفضيلاتك" />
      <EmptyState
        title="صفحة الإعدادات قادمة في المرحلة 7"
        description="ستضم إعدادات الحساب، الإشعارات، الخصوصية، والمظهر."
      />
    </div>
  );
}
