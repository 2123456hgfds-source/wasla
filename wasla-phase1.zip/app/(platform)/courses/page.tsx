import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function CoursesPage() {
  return (
    <div>
      <PageHeader title="الكورسات" description="تعلّم بأسلوب Classroom منظم" />
      <EmptyState
        title="صفحة الكورسات قادمة في المرحلة 4"
        description="ستضم قائمة الكورسات، تفاصيل كل كورس ودروسه (فيديو، نص، PDF، روابط)، وتتبع التقدم."
      />
    </div>
  );
}
