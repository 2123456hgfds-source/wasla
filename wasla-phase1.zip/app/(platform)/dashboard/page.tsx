import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function DashboardPage() {
  return (
    <div>
      <PageHeader title="الرئيسية" description="نظرة سريعة على نشاط مجتمعك" />
      <EmptyState
        title="لوحة التحكم قادمة في المرحلة 2"
        description="هذه الصفحة ستعرض الإحصائيات، النشاط الأخير، أحدث المنشورات، الأحداث القادمة، وأكثر الأعضاء نشاطًا."
      />
    </div>
  );
}
