import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function NotificationsPage() {
  return (
    <div>
      <PageHeader title="الإشعارات" description="كل ما يحدث في مجتمعك" />
      <EmptyState
        title="صفحة الإشعارات قادمة في المرحلة 7"
        description="ستضم إشعارات المنشورات، التعليقات، الرسائل، الأحداث، وإكمال الدروس."
      />
    </div>
  );
}
