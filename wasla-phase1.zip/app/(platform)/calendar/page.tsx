import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function CalendarPage() {
  return (
    <div>
      <PageHeader title="التقويم" description="الفعاليات والجلسات المباشرة" />
      <EmptyState
        title="صفحة التقويم قادمة في المرحلة 5"
        description="ستضم عرض شهري وأسبوعي، إنشاء حدث، جلسات مباشرة، وتذكيرات."
      />
    </div>
  );
}
