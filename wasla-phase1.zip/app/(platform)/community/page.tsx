import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function CommunityPage() {
  return (
    <div>
      <PageHeader title="المجتمع" description="شارك أفكارك وتفاعل مع الأعضاء" />
      <EmptyState
        title="صفحة المجتمع قادمة في المرحلة 3"
        description="ستضم فيد منشورات تفاعلي: إنشاء منشور، صور وملفات، تعليقات، لايك، تثبيت، هاشتاقات، ومنشن."
      />
    </div>
  );
}
