import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function MessagesPage() {
  return (
    <div>
      <PageHeader title="الرسائل" description="محادثاتك الخاصة مع الأعضاء" />
      <EmptyState
        title="صفحة الرسائل غير مطلوبة بعد ضمن القائمة الأساسية"
        description="ظهرت في الـ Sidebar حسب طلبك، وإذا حبيت نبنيها كمرحلة إضافية بعد إنهاء الـ 8 مراحل، فقط اطلب ذلك."
      />
    </div>
  );
}
