import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function MembersPage() {
  return (
    <div>
      <PageHeader title="الأعضاء" description="تعرّف على أعضاء المجتمع" />
      <EmptyState
        title="صفحة الأعضاء قادمة في المرحلة 6"
        description="ستضم قائمة الأعضاء مع الصورة، النبذة، مستوى العضوية، وعدد النقاط."
      />
    </div>
  );
}
