import { PageHeader } from "@/components/layout/page-header";
import { EmptyState } from "@/components/ui/empty-state";

export default function ProfilePage() {
  return (
    <div>
      <PageHeader title="الملف الشخصي" description="صورتك، نبذتك، وإنجازاتك" />
      <EmptyState
        title="صفحة الملف الشخصي قادمة في المرحلة 6"
        description="ستضم الصورة، النبذة، الإنجازات، النقاط، الكورسات المكتملة، والنشاط."
      />
    </div>
  );
}
